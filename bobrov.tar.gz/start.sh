#!/bin/bash

localization=0

while [ $localization -ne 1 ] && [ $localization -ne 2 ]
do
    echo "Выбери язык команд:"
    echo "русский - 1"
    echo "английский - 2"
    read -r -p "введи свой выбор: " localization
done

if [ $localization -eq 1 ]; then localization=ru_commands; else localization=en_commands; fi

{
read -r end_cmd next_day_cmd log_cmd help_cmd get_commands_command
read -r add_worker remove_worker woodcutter_name forester_name carpenter_name builder_name
} < $localization

{
read -r beaver_out beaver_in
read -r woodcutter forester carpenter builder no_work
read -r forest forest_row log wood house
read -r day days_for_end
} < difficult

t="$(printf '\t')"

echo "Чтобы получить полезную информацию для начала игры, введи $help_cmd"

function min() {
    if [[ $1 -lt $2 ]]; then echo $1; else echo $2; fi
}

function add_beavers_profession() {
    if [ -z $2 ]; then addition=1;
    else
        addition=$2
    fi
    if [ $no_work -lt $addition ]; then echo "всего безработных бобров $no_work"; return; fi
    no_work=$(( no_work - $addition ))
    _=$(( $1=$(( $1 + $addition )) ))
}

function update_trees() {
    while read line; do
        line=$(( line + 1 ))
        if [ $line -eq 2 ]; then
            forest=$(( forest + 1 ))
            forest_row=$(( forest_row - 1 ))
        else
            echo $line
        fi
    done < tree > buffer

    new_forest=$forester
    while [ $new_forest -ne 0 ]; do
        echo 0
        new_forest=$(( new_forest - 1 ))
    done >> buffer

    while read line; do echo $line; done < buffer > tree
}

function remove_beavers_profession() {
    if [ -z $2 ]; then addition=1;
    else
        addition=$2
    fi
    if [ $(( $1 )) -lt $addition ]; then echo "всего бобров на данной работе $(( $1 ))"; return; fi
    no_work=$(( no_work + $addition ))
    _=$(( $1=$(( $1 - $addition )) ))
}

function end_game() {
    > tree
    > buffer
    exit
}

function print_progress() {
    echo "Прогресс:"
    echo -n "$beaver_in "
    for ((i=0; i<=beaver_in-1; i++)); do echo -n =; done
    for ((i=0; i<=beaver_out-1; i++)); do echo -n -; done
    echo " $(( beaver_in+beaver_out ))"
    echo
}

trap "end_game" SIGINT

function main() {
    cmd=$1

    if [ "$cmd" == "$end_cmd" ]; then
        end_game

    elif [ "$cmd" == "$next_day_cmd" ]; then
        forest_row=$(( forest_row + forester ))
        update_trees
        log=$(( log + `min $woodcutter $forest` ))
        forest=$(( forest - `min $woodcutter $forest` ))

        wood=$(( wood + `min $carpenter $log` ))
        log=$(( log - `min $carpenter $log` ))

        new_house=`min $wood $builder`
        house=$(( house + new_house ))
        wood=$(( wood - new_house ))

        beaver_in=$(( beaver_in + new_house ))
        beaver_out=$(( beaver_out - new_house ))

        day=$(( day + 1))

        if [ $beaver_out -lt 1 ]
        then
            echo "you win!"
            exit
        fi
        print_progress

    elif [ "$cmd" == "$help_cmd" ]; then
        line=$(<help_description)
        eval "echo \"$line\""

    elif [ "$cmd" == "$get_commands_command" ]; then
        line=$(<commands_description)
        eval "echo \"$line\""

    elif [ "$cmd" == "$log_cmd" ]; then
        print_progress

        echo
        echo "Бездомных бобров: $beaver_out"
        echo "Бобров в хатке: $beaver_in"
        echo
        echo "Лесников$t | Дровосеков$t | Плотников$t | Строителей$t | Безработных"
        echo "$woodcutter$t$t | $forester$t$t | $carpenter$t$t | $builder$t$t | $no_work"
        echo
        echo "Ростков$t$t | Деревьев$t | Бревен$t | Досок$t | Хаток"
        echo "$forest_row$t$t | $forest$t$t | $log$t$t | $wood$t$t | $house"
        echo
        echo "День: $day$t$t Из: $days_for_end"
        echo

    elif [ "$cmd" == "$add_worker" ]; then
        if [ "$2" == "$woodcutter_name" ]; then add_beavers_profession woodcutter $3, echo "Успешно добавлены $3 дровосека"
        elif [ "$2" == "$forester_name" ]; then add_beavers_profession forester $3, echo "Успешно добавлены $3 лесника"
        elif [ "$2" == "$carpenter_name" ]; then add_beavers_profession carpenter $3, echo "Успешно добавлены $3 столяра"
        elif [ "$2" == "$builder_name" ]; then add_beavers_profession builder $3, echo "Успешно добавлены $3 строителей"
        else echo "Введено неправильное название профессии", return
        fi

    elif [ "$cmd" == "$remove_worker" ]; then
        if [ "$2" == "$woodcutter_name" ]; then remove_beavers_profession woodcutter $3, echo "Успешно уволены $3 дровосека"
        elif [ "$2" == "$forester_name" ]; then remove_beavers_profession forester $3, echo "Успешно уволены $3 лесника"
        elif [ "$2" == "$carpenter_name" ]; then remove_beavers_profession carpenter $3, echo "Успешно уволены $3 столяра"
        elif [ "$2" == "$builder_name" ]; then remove_beavers_profession builder $3, echo "Успешно уволены $3 строителей"
        else echo "Введено неправильное название профессии"
        fi

    else
        echo "Введена неправильная команда"
    fi
}

last_command=""
read -r -p "enter your command: " command
while [ $day -lt $days_for_end ]
do
    # shellcheck disable=SC2086
    if [ "$command" == "[A" ]; then
        main $last_command
    else
        main $command
        last_command="$command"
    fi
    read -r -p "enter your command: " command
done

echo "you loose"
